# 🤖 Agentic AI — Autonomous Reasoning & Decision-Making System

**Author:** Shreya Shailendra Shende  
**Theme:** Decision-Making AI / Autonomous Systems  
**Event:** Unstop AI Innovation Challenge  

---

## 📌 Project Overview

This project demonstrates a fully **Agentic AI system** capable of autonomous **task planning, reasoning, and execution** with zero human intervention.

The agent operates in a continuous loop:

```
PERCEIVE → REASON → PLAN → EXECUTE
```

It leverages a **knowledge graph** for causal reasoning and a **Q-table (Reinforcement Learning)** for adaptive decision-making, dynamically improving its performance across cycles.

---

## 🗂️ Repository Structure

```
Agentic-AI-Project/
│
├── README.md
├── requirements.txt
│
├── code/
│   ├── main.py          ← Entry point — run this
│   ├── agent.py         ← AgentCore: Reason + Execute (RL + Knowledge Graph)
│   ├── planner.py       ← TaskPlanner: generates step-by-step action plans
│   ├── environment.py   ← Simulated environment with dynamic task generation
│   └── logger.py        ← Logs cycles, saves CSV + matplotlib charts
│
├── data/
│   └── sample_data.csv  ← Pre-recorded simulation results (all 4 scenarios)
│
├── diagrams/
│   └── architecture.png ← System architecture diagram
│
└── results/
    ├── simulation_output.png  ← Auto-generated chart after each run
    └── simulation_log.csv     ← Auto-generated CSV log after each run
```

---

## 🚀 Getting Started

### 1. Clone the repository
```bash
git clone https://github.com/YourUsername/Agentic-AI-Project.git
cd Agentic-AI-Project
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```
> Only `matplotlib` is required. The core simulation runs on **Python 3.8+ standard library**.

### 3. Run the simulation
```bash
# Default scenario (Smart City)
python code/main.py

# Choose a specific scenario
python code/main.py --scenario healthcare
python code/main.py --scenario logistics
python code/main.py --scenario energy
python code/main.py --scenario smart_city
```

### 4. View results
After running, check the `results/` folder:
- `simulation_output.png` — efficiency & stress chart
- `simulation_log.csv`    — full cycle-by-cycle log

---

## ⚙️ How It Works

### Agent Cycle (5 steps per simulation)

| Stage | Module | Description |
|-------|--------|-------------|
| **Perceive** | `environment.py` | Reads pending tasks & environment stress level |
| **Reason** | `agent.py` | Scores tasks using Knowledge Graph + Q-table (RL) |
| **Plan** | `planner.py` | Decomposes top task into ordered sub-steps |
| **Execute** | `agent.py` | Applies steps to environment, updates Q-table |
| **Log** | `logger.py` | Records metrics, saves chart & CSV |

### Knowledge Graph (in `agent.py`)
Maps task types → causes → recommended actions:
```
traffic_jam     → high_vehicle_density → reroute_vehicles
patient_critical→ vitals_anomaly       → alert_medical_team
power_surge     → peak_demand          → load_balance
supply_delay    → route_congestion     → find_alt_route
```

### Reinforcement Learning (Q-table update)
```
Q(state) ← Q(state) + α × (reward − Q(state))
```
The agent improves action selection across cycles without retraining.

---

## 🌍 Supported Scenarios

| Scenario | Key Task | Domain |
|----------|----------|--------|
| `smart_city` | Traffic jam, anomaly detection | Urban infrastructure |
| `healthcare` | Patient critical alerts, vitals | Hospital AI |
| `logistics` | Supply delay, route optimization | Supply chain |
| `energy` | Power surge, load balancing | Smart grid |

---

## 📊 Sample Results

> Generated automatically — run `python code/main.py` to reproduce.

![Simulation Output](results/simulation_output.png)

**Typical performance metrics:**
- ✅ Avg Execution Efficiency: **66–93%**
- ✅ Human Interventions: **0** (fully autonomous)
- ✅ Decision Latency: **< 30 ms** avg
- ✅ Tasks Resolved per Run: **10–15**

---

## ✨ Key Features

- **Autonomous task planning and execution** — no human-in-the-loop
- **Knowledge graph reasoning** — causal inference for action selection
- **Online Q-learning** — agent improves with every cycle
- **Multi-task handling** — primary + secondary task resolution per cycle
- **4 real-world scenarios** — smart city, healthcare, logistics, energy
- **Auto-generated charts and CSV logs** — results ready for submission

---

## 🔮 Future Scope

- Integration with real-time IoT sensor feeds
- Multi-agent network with inter-agent communication
- Deep Q-Network (DQN) to replace the Q-table for complex state spaces
- REST API wrapper to deploy agent as a microservice
- Deployment on edge hardware (NVIDIA Jetson / Raspberry Pi)

---

## 📄 License

MIT License — free to use, modify, and distribute.
