"""
environment.py — Simulated Environment
Generates dynamic tasks and applies agent actions.
Supports: smart_city, healthcare, logistics, energy scenarios.
"""

import random
from typing import Dict, Any, List


# Scenario-specific task pools
SCENARIO_TASKS: Dict[str, List[str]] = {
    "smart_city": [
        "traffic_jam", "sensor_fault", "resource_shortage", "anomaly_detected",
    ],
    "healthcare": [
        "patient_critical", "sensor_fault", "resource_shortage", "anomaly_detected",
    ],
    "logistics": [
        "supply_delay", "sensor_fault", "resource_shortage", "anomaly_detected",
    ],
    "energy": [
        "power_surge", "sensor_fault", "resource_shortage", "anomaly_detected",
    ],
}


class Environment:
    """
    Simulated environment that generates tasks and responds to agent actions.
    Stress level rises each step; resolved tasks reduce it.
    """

    def __init__(self, scenario: str = "smart_city"):
        self.scenario    = scenario
        self.task_pool   = SCENARIO_TASKS.get(scenario, SCENARIO_TASKS["smart_city"])
        self.tasks       = self._spawn_tasks(initial=True)
        self._stress     = round(random.uniform(0.4, 0.7), 2)
        self._step_count = 0

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------
    def _spawn_tasks(self, initial: bool = False) -> List[str]:
        n = random.randint(2, 4) if not initial else random.randint(3, 4)
        return random.choices(self.task_pool, k=n)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def observe(self) -> Dict[str, Any]:
        """Return current environment state snapshot."""
        return {
            "scenario":      self.scenario,
            "pending_tasks": list(self.tasks),
            "stress_level":  round(self._stress, 2),
            "step":          self._step_count,
        }

    def apply_action(self, action: str, target: str) -> Dict[str, Any]:
        """
        Apply a single action step.
        Returns success flag and efficiency score.
        """
        # Actions that target actual tasks resolve them
        resolved = target in self.tasks
        if resolved:
            self.tasks = [t for t in self.tasks if t != target]
            self._stress = max(0.0, self._stress - random.uniform(0.05, 0.12))
            eff = round(random.uniform(0.72, 0.96), 3)
        else:
            eff = round(random.uniform(0.50, 0.70), 3)

        return {
            "success":    True,          # action always executes (hardware layer OK)
            "resolved":   resolved,
            "efficiency": eff,
        }

    def step(self):
        """Advance environment by one time step — new tasks may appear."""
        self._step_count += 1
        # Stress drifts up slightly each cycle (environment degrades without agent)
        self._stress = min(1.0, self._stress + random.uniform(0.02, 0.06))
        # 60% chance a new task spawns each step
        if random.random() < 0.6:
            new_task = random.choice(self.task_pool)
            if new_task not in self.tasks:
                self.tasks.append(new_task)
