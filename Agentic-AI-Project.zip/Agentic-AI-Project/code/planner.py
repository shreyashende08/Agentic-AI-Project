"""
planner.py — TaskPlanner
Converts agent reasoning output into an ordered, executable action plan.
Supports two strategies:
  - priority_rl  : priority queue driven by RL scores  (default)
  - round_robin  : cycles through tasks evenly
"""

import random
from typing import Dict, Any, List


# Each action template defines how steps are decomposed
ACTION_TEMPLATES: Dict[str, List[str]] = {
    "reroute_vehicles":    ["scan_traffic_grid", "compute_alt_paths", "dispatch_reroute_signal"],
    "load_balance":        ["monitor_grid_load",  "identify_overload_nodes", "redistribute_power"],
    "alert_medical_team":  ["verify_vitals_feed", "classify_severity",       "notify_on_call_doctor"],
    "find_alt_route":      ["query_route_db",      "check_availability",      "update_dispatch_order"],
    "switch_to_backup":    ["ping_backup_sensor",  "validate_data_stream",    "reroute_data_pipeline"],
    "rebalance_resources": ["audit_resource_pool", "rank_deficits",           "reallocate_units"],
    "escalate_analysis":   ["capture_anomaly_log", "run_pattern_match",       "flag_for_review"],
    "monitor":             ["idle_scan"],
    "generic_response":    ["log_event", "notify_operator"],
}


class TaskPlanner:
    """
    Autonomous task planner.
    Takes reasoning output and returns a concrete step-by-step plan.
    """

    def __init__(self, strategy: str = "priority_rl"):
        self.strategy = strategy
        self._plan_count = 0

    def generate_plan(self, reasoning: Dict[str, Any]) -> Dict[str, Any]:
        """
        Build a plan dict containing:
          steps          : list of {action, target, priority}
          efficiency_gain: projected improvement ratio
          strategy_used  : which planner mode was chosen
        """
        self._plan_count += 1
        action  = reasoning["action"]
        task    = reasoning["top_task"]
        conf    = reasoning["confidence"]

        sub_steps = ACTION_TEMPLATES.get(action, ACTION_TEMPLATES["generic_response"])

        steps = []
        for i, sub in enumerate(sub_steps):
            steps.append({
                "step_id":  i + 1,
                "action":   sub,
                "target":   task,
                "priority": round(conf - i * 0.05, 3),
            })

        # Include lower-priority tasks as secondary steps (multi-agent style)
        secondary = reasoning.get("all_scored", [])[1:3]   # next 2 tasks
        for sec in secondary:
            sec_steps = ACTION_TEMPLATES.get(sec["action"], ["log_event"])
            steps.append({
                "step_id":  len(steps) + 1,
                "action":   sec_steps[0],           # only first sub-step for secondary
                "target":   sec["task"],
                "priority": round(sec["score"] * 0.6, 3),
            })

        # Sort by priority descending
        steps.sort(key=lambda x: x["priority"], reverse=True)

        # Projected efficiency gain (heuristic)
        base_gain  = conf * 0.45
        bonus      = 0.05 * len(steps)
        efficiency = min(base_gain + bonus + random.uniform(0, 0.05), 0.98)

        return {
            "plan_id":        self._plan_count,
            "primary_action": action,
            "steps":          steps,
            "efficiency_gain": efficiency,
            "strategy_used":  self.strategy,
        }
